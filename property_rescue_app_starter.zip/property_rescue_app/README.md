# Property Rescue — starter application

This is a development starter for the Property Rescue website and enquiry/admin workflow.

## 1. Configure Supabase
1. Copy `.env.example` to `.env` in the project root.
2. Set `VITE_SUPABASE_URL` to your Supabase project URL.
3. Set `VITE_SUPABASE_PUBLISHABLE_KEY` to your `sb_publishable_...` key.
4. Do not put a database password or `service_role` / secret key in this file.

## 2. Run locally
Install Node.js (LTS), then in this folder run:
```bash
npm install
npm run dev
```
Open the local URL printed by Vite.

## 3. Current functionality
- Public enquiry form inserts into `public.enquiries`.
- Admin sign-in uses Supabase email/password authentication.
- Signed-in admin can view recent enquiries.

## Important security limitations
This is a development starter, not a production-ready CRM. The SQL policies created during setup allow every authenticated user to manage all rows. Before production, restrict access to a verified admin identity or role, turn off public sign-ups, add anti-spam/rate limiting, privacy/retention controls, and test policies. Do not store sensitive customer documents or use real customer records until these checks are complete.

## 4. Deployment
Deploy the built Vite site to Cloudflare Pages. Configure the two `VITE_` environment variables in the Cloudflare Pages project settings. These are public browser configuration values; database security must be enforced by Supabase RLS policies.
